set -eux
echo 'export ONOS_OPTS=debug' > /opt/onos/options;
echo 'export ONOS_USER=root' >> /opt/onos/options;
mkdir /opt/onos/var;
mkdir /opt/onos/config;

rm -rf /opt/feature_install.sh
touch /opt/feature_install.sh
cat <<EOT>> /opt/feature_install.sh
#!/bin/bash
set -eux
/opt/onos/bin/onos "feature:install onos-openflow"
sleep 1
/opt/onos/bin/onos "feature:install onos-openflow-base"
sleep 1
/opt/onos/bin/onos "feature:install onos-ovsdatabase"
sleep 1
/opt/onos/bin/onos "feature:install onos-ovsdb-base"
sleep 1
/opt/onos/bin/onos "feature:install onos-drivers-ovsdb"
sleep 1
/opt/onos/bin/onos "feature:install onos-ovsdb-provider-host"
sleep 1
/opt/onos/bin/onos "feature:install onos-app-vtn-onosfw"
sleep 2
/opt/onos/bin/onos "externalportname-set -n onos_port2"
EOT
