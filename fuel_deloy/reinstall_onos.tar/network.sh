#/bin/bash

set -eux
mac=52:54:00:61:37:05
puppet apply  create_network.pp
sleep 10
puppet apply create_router.pp
/opt/onos/bin/onos "externalgateway-update -m $mac"
