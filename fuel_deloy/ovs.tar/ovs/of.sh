
#/bin/bash

set -ux

ovs-ofctl dump-flows -O openflow13 br-int
