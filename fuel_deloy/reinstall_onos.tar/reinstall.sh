#/bin/bash
set -ux
service onos stop

mgr_ip=$(ovs-vsctl show | grep Manager | grep -Eo "[0-9]+.[0-9]+.[0-9]+.[0-9]+")
ovs-vsctl del-manager
ovs-vsctl del-br br-int
ovs-vsctl show

rm -rf /opt/onos
cd /opt
tar zxf onos*.tar.gz
mv onos*onos onos
cd /etc/puppet/manifests
./onos_config.sh
puppet apply service.pp

sleep 10
ovs-vsctl show
ovs-vsctl set-manager tcp:$mgr_ip:6640
sleep 1
ovs-vsctl show


