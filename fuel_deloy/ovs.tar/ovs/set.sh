#/bin/bash

set -ux

ovs-vsctl show
ovs-vsctl set-manager tcp:192.168.0.13:6640
ovs-vsctl show

