#/bin/bash

set -ux

ovs-vsctl show
ovs-vsctl del-manager
ovs-vsctl del-br br-int
ovs-vsctl del-br br-floating
ovs-vsctl show
